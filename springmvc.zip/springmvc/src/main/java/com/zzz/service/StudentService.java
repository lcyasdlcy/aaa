package com.zzz.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zzz.dao.StudentDAO;
import com.zzz.entity.Student;

@Service
public class StudentService {

	@Resource
	private StudentDAO studao;

	public List<Student> getAllStudents() {
		return studao.findAll();
	}
}
