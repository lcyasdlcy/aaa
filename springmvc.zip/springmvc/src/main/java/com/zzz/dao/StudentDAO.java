package com.zzz.dao;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.zzz.entity.Student;
import com.zzz.mapper.StudentMapper;

@Repository
public class StudentDAO {
	@Resource
	private JdbcTemplate template;

	public List<Student> findAll() {
		String sql = "select * from student";
		StudentMapper rowMapper = new StudentMapper();
		List<Student> list = template.query(sql, rowMapper);
		return list;
	}

}
