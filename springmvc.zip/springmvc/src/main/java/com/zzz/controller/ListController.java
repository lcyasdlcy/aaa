package com.zzz.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.zzz.dao.StudentDAO;
import com.zzz.entity.Student;
import com.zzz.service.StudentService;

@Controller
public class ListController {

	@Autowired
	private StudentDAO dao;
	@Autowired
	private StudentService service;

	@RequestMapping("/list")
	public ModelAndView execute() {
		ModelAndView mav = new ModelAndView();
		List<Student> list = dao.findAll();
		mav.getModel().put("list1", list);
		mav.setViewName("list");
		return mav;
	}

	@RequestMapping("/list1")
	public ModelAndView execute1() {
		ModelAndView mav = new ModelAndView();
		List<Student> list = dao.findAll();
		mav.getModel().put("list1", list.subList(0, 3));
		mav.setViewName("list");
		return mav;
	}
	
	@ResponseBody
	@RequestMapping(value="/student", method=RequestMethod.GET)
	public Object getAll() {
		return dao.findAll();
	}
}
