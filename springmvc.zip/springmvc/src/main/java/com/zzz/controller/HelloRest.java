package com.zzz.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/rest")
public class HelloRest {

	@RequestMapping(value = "/hello", produces = "text/html;charset=utf-8")
	public String hello() {
		return "hello,rest.你好。";
	}

	@ResponseBody
	@RequestMapping(value = "/test1", produces = "application/json;charset=utf-8")
	public String test1() {
		return "{\"name\":\"小明\",\"age\":22}";
	}
}
