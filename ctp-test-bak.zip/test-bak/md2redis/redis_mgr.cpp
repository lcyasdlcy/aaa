#include "redis_mgr.h"

bool RedisMgr::Connect(string addr, int port)
{
	c = redisConnect(addr.c_str(), port);
	if ( c->err)
    {
        printf("Connect to redisServer faile:%s\n",c->errstr);
        redisFree(c);
        return false;
    }
    printf("Connect to redisServer Success\n");
	return true;
}
void RedisMgr::Close()
{
	redisFree(c);
	printf("Close from redisServer Success\n");
}
void RedisMgr::Publish(string &channel, string &message)
{
	redisReply *reply;
	reply = (redisReply *)redisCommand(c, "PUBLISH %s %s", channel.c_str(), message.c_str());
	freeReplyObject(reply);
	printf("Publish message Success\n");
}
void RedisMgr::LPush(string &queue, string &message)
{
	redisReply *reply;
	reply = (redisReply *)redisCommand(c, "LPUSH %s %s", queue.c_str(), message.c_str());
	freeReplyObject(reply);
}
void RedisMgr::BRPop(redisReply **reply, string &queue, int timeout)
{
	*reply = (redisReply *)redisCommand(c, "BRPOP %s %d", queue.c_str(), timeout);
}