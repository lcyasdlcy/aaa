#ifndef _REDIS_MGR_H_
#define _REDIS_MGR_H_

#include "hiredis.h"
#include <iostream>
using namespace std;

class RedisMgr
{
public:
	RedisMgr()
	{
		c = NULL;
	}
	//~RedisMgr()
	//{
	//	if (c!=NULL)
	//		delete c;
	//}
	bool Connect(string addr, int port);
	void Close();
	void Publish(string &channel, string &message);
	void LPush(string &queue, string &message);
	void BRPop(redisReply **reply, string &queue, int timeout=0);
protected:
private:
	redisContext* c;
};

#endif
