#ifndef _CONF_MGR_H_
#define _CONF_MGR_H_

#include <iostream>
#include <vector>
using namespace std;

class ConfMgr
{
public:
	ConfMgr(string filename="conf.xml");
	void Init();
	string GetMdAddr();
	string GetTradeAddr();
	string GetBrokerID();
	string GetUserID();
	string GetPassword();
	string GetRedisAddr();
	int GetRedisPort();
	string GetRedisMdChnl();
	string GetInstrumentQueue();
	vector<string> GetInstrumentIdList();
protected:

private:
	string filename;
	string mdAddr;
	string tradeAddr;
	string brokerID;
	string userID;
	string password;
	string redisAddr;
	int redisPort;
	string redisMdChnl;
	string instrumentQueue;
	vector<string> instrumentIdList;
};
#endif