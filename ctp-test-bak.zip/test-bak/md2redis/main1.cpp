#include <iostream>
#include <sstream>
#include <string>
#include "ThostFtdcMdApi.h"
#include "ThostFtdcTraderApi.h"
#include "redis_mgr.h"
#include "conf_mgr.h"
#include <windows.h>

#pragma comment (lib, "thostmduserapi.lib")
#pragma comment (lib, "thosttraderapi.lib")

using namespace std;

HANDLE g_hEvent1 = CreateEvent(NULL, true, false, NULL);
ConfMgr g_confMgr;

class SimpleMdHandler : public CThostFtdcMdSpi
{
public:
	SimpleMdHandler(CThostFtdcMdApi *pUserApi) : m_pUserApi(pUserApi) {}
	~SimpleMdHandler() {}
	void OnFrontConnected();
	void OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	void OnRtnDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData);

	void InitRedisMgr()
	{
		m_pRedisMgr = new RedisMgr;
		m_pRedisMgr->Connect(g_confMgr.GetRedisAddr(), g_confMgr.GetRedisPort());
	}
private:
	CThostFtdcMdApi *m_pUserApi;
	RedisMgr *m_pRedisMgr;
};

class SimpleTradeHandler : public CThostFtdcTraderSpi
{
public:
	SimpleTradeHandler(CThostFtdcTraderApi *pUserApi) : m_pUserApi(pUserApi) {}
	~SimpleTradeHandler() {}
	void OnFrontConnected();
	void OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);
	void OnRspQryInstrument(CThostFtdcInstrumentField *pInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast);

	void InitRedisMgr()
	{
		m_pRedisMgr = new RedisMgr;
		m_pRedisMgr->Connect(g_confMgr.GetRedisAddr(), g_confMgr.GetRedisPort());
	}
private:
	CThostFtdcTraderApi *m_pUserApi;
	RedisMgr *m_pRedisMgr;
};

void SimpleMdHandler::OnFrontConnected()
{
	cout<<"���������ַ�ɹ�����������û���¼��"<<endl;
	CThostFtdcReqUserLoginField loginReq;
	memset(&loginReq, 0, sizeof(loginReq));
	strcpy(loginReq.BrokerID, g_confMgr.GetBrokerID().c_str());
	strcpy(loginReq.UserID, g_confMgr.GetUserID().c_str());
	strcpy(loginReq.Password, g_confMgr.GetPassword().c_str());
	static int requestID = 0;
	m_pUserApi->ReqUserLogin(&loginReq, requestID);
}

void SimpleMdHandler::OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	bool bResult = pRspInfo && (pRspInfo->ErrorID != 0);
	if (!bResult) {
		cout<<"�����˻���¼�ɹ��������������ע�ᡣ"<<endl;
		SetEvent(g_hEvent1);
	} else {
		std::cerr << "���ش���--->>> ErrorID=" << pRspInfo->ErrorID << ", ErrorMsg=" << pRspInfo->ErrorMsg << std::endl;
	}
}

void SimpleMdHandler::OnRtnDepthMarketData(CThostFtdcDepthMarketDataField *pDepthMarketData)
{
	cout<<"�������飺"<<endl;
	cout<<"��Լ���룺"<<pDepthMarketData->InstrumentID<<endl;
	std::stringstream ss;
	ss<<"{"
		<<"\"TradingDay\":\""<<pDepthMarketData->TradingDay<<"\","
		<<"\"ExchangeID\":\""<<pDepthMarketData->ExchangeID<<"\","
		<<"\"InstrumentID\":\""<<pDepthMarketData->InstrumentID<<"\","
		<<"\"ExchangeInstID\":\""<<pDepthMarketData->ExchangeInstID<<"\","
		<<"\"LastPrice\":"<<pDepthMarketData->LastPrice<<","
		<<"\"PreSettlementPrice\":"<<pDepthMarketData->PreSettlementPrice<<","
		<<"\"PreClosePrice\":"<<pDepthMarketData->PreClosePrice<<","
		<<"\"PreOpenInterest\":"<<pDepthMarketData->PreOpenInterest<<","
		<<"\"OpenPrice\":"<<pDepthMarketData->OpenPrice<<","
		<<"\"HighestPrice\":"<<pDepthMarketData->HighestPrice<<","
		<<"\"LowestPrice\":"<<pDepthMarketData->LowestPrice<<","
		<<"\"Volume\":"<<pDepthMarketData->Volume<<","
		<<"\"Turnover\":"<<pDepthMarketData->Turnover<<","
		<<"\"OpenInterest\":"<<pDepthMarketData->OpenInterest<<","
		<<"\"ClosePrice\":"<<pDepthMarketData->ClosePrice<<","
		<<"\"SettlementPrice\":"<<pDepthMarketData->SettlementPrice<<","
		<<"\"UpperLimitPrice\":"<<pDepthMarketData->UpperLimitPrice<<","
		<<"\"LowerLimitPrice\":"<<pDepthMarketData->LowerLimitPrice<<","
		<<"\"PreDelta\":"<<pDepthMarketData->PreDelta<<","
		<<"\"CurrDelta\":"<<pDepthMarketData->CurrDelta<<","
		<<"\"UpperLimitPrice\":"<<pDepthMarketData->UpperLimitPrice<<","
		<<"\"LowerLimitPrice\":"<<pDepthMarketData->LowerLimitPrice<<","
		<<"\"PreDelta\":"<<pDepthMarketData->PreDelta<<","
		<<"\"CurrDelta\":"<<pDepthMarketData->CurrDelta<<","
		<<"\"UpdateTime\":\""<<pDepthMarketData->UpdateTime<<"\","
		<<"\"UpdateMillisec\":"<<pDepthMarketData->UpdateMillisec<<","
		<<"\"BidPrice1\":"<<pDepthMarketData->BidPrice1<<","
		<<"\"BidVolume1\":"<<pDepthMarketData->BidVolume1<<","
		<<"\"AskPrice1\":"<<pDepthMarketData->AskPrice1<<","
		<<"\"AskVolume1\":"<<pDepthMarketData->AskVolume1<<","
		<<"\"BidPrice2\":"<<pDepthMarketData->BidPrice2<<","
		<<"\"BidVolume2\":"<<pDepthMarketData->BidVolume2<<","
		<<"\"AskPrice2\":"<<pDepthMarketData->AskPrice2<<","
		<<"\"AskVolume2\":"<<pDepthMarketData->AskVolume2<<","
		<<"\"BidPrice3\":"<<pDepthMarketData->BidPrice3<<","
		<<"\"BidVolume3\":"<<pDepthMarketData->BidVolume3<<","
		<<"\"AskPrice3\":"<<pDepthMarketData->AskPrice3<<","
		<<"\"AskVolume3\":"<<pDepthMarketData->AskVolume3<<","
		<<"\"BidPrice4\":"<<pDepthMarketData->BidPrice4<<","
		<<"\"BidVolume4\":"<<pDepthMarketData->BidVolume4<<","
		<<"\"AskPrice4\":"<<pDepthMarketData->AskPrice4<<","
		<<"\"AskVolume4\":"<<pDepthMarketData->AskVolume4<<","
		<<"\"BidPrice5\":"<<pDepthMarketData->BidPrice5<<","
		<<"\"BidVolume5\":"<<pDepthMarketData->BidVolume5<<","
		<<"\"AskPrice5\":"<<pDepthMarketData->AskPrice5<<","
		<<"\"AskVolume5\":"<<pDepthMarketData->AskVolume5<<","
		<<"\"AveragePrice\":"<<pDepthMarketData->AveragePrice<<","
		<<"\"ActionDay\":\""<<pDepthMarketData->ActionDay<<"\""
		<<"}";
	//std::cout<<ss.str()<<std::endl;
	static string mdChnl = g_confMgr.GetRedisMdChnl();
	m_pRedisMgr->Publish(mdChnl, ss.str());
}

void SimpleTradeHandler::OnFrontConnected()
{
	cout<<"���ӽ��׵�ַ�ɹ�����������û���¼��"<<endl;
	CThostFtdcReqUserLoginField loginReq;
	memset(&loginReq, 0, sizeof(loginReq));
	strcpy(loginReq.BrokerID, g_confMgr.GetBrokerID().c_str());
	strcpy(loginReq.UserID, g_confMgr.GetUserID().c_str());
	strcpy(loginReq.Password, g_confMgr.GetPassword().c_str());
	static int requestID = 0;
	m_pUserApi->ReqUserLogin(&loginReq, requestID);
}
void SimpleTradeHandler::OnRspUserLogin(CThostFtdcRspUserLoginField *pRspUserLogin, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	bool bResult = pRspInfo && (pRspInfo->ErrorID != 0);
	if (!bResult) {
		cout<<"�����˻���¼�ɹ���������к�Լ�����ѯ��"<<endl;
		CThostFtdcQryInstrumentField req;
		memset(&req, 0, sizeof(req));
		int n = m_pUserApi->ReqQryInstrument(&req, 0);
		if (n)
			cerr<<"���ͺ�Լ�����ѯ����ʧ�ܡ�"<<endl;
		else
			cout<<"���ͺ�Լ�����ѯ����ɹ���"<<endl;
	} else {
		std::cerr << "���ش���--->>> ErrorID=" << pRspInfo->ErrorID << ", ErrorMsg=" << pRspInfo->ErrorMsg << std::endl;
	}
}
void SimpleTradeHandler::OnRspQryInstrument(CThostFtdcInstrumentField *pInstrument, CThostFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	bool bResult = pRspInfo && (pRspInfo->ErrorID != 0);
	if (!bResult) {
		static string insQue = g_confMgr.GetInstrumentQueue();
		m_pRedisMgr->LPush(insQue, string(pInstrument->InstrumentID));
		//cout<<"��Լ���룺 "<<pInstrument->InstrumentID<<endl;
	} else {
		std::cerr << "���ش���--->>> ErrorID=" << pRspInfo->ErrorID << ", ErrorMsg=" << pRspInfo->ErrorMsg << std::endl;
	}
}

int main()
{
	//��ʼ��socket��windows��Ҫ
	WSADATA wsaData;
    int nRet;
    if((nRet = WSAStartup(MAKEWORD(2,2),&wsaData)) != 0){
        printf("WSAStartup failed\n");
        exit(0);
    }
	//��ʼ������
	g_confMgr.Init();
	//����redis������������ǻ�ȡ���к�Լ����ʱ��
	RedisMgr rm;
	rm.Connect(g_confMgr.GetRedisAddr(), g_confMgr.GetRedisPort());
	//���ף��������ڻ�ȡ���к�Լ����
	CThostFtdcTraderApi *pTraderApi = CThostFtdcTraderApi::CreateFtdcTraderApi();
	SimpleTradeHandler sth(pTraderApi);
	sth.InitRedisMgr();
	pTraderApi->RegisterSpi(&sth);
	pTraderApi->RegisterFront((char*)g_confMgr.GetTradeAddr().c_str());
	pTraderApi->Init();
	//���飬ʵ������������
	CThostFtdcMdApi *pUserApi = CThostFtdcMdApi::CreateFtdcMdApi();
	SimpleMdHandler smh(pUserApi);
	smh.InitRedisMgr();
	pUserApi->RegisterSpi(&smh);
	pUserApi->RegisterFront((char*)g_confMgr.GetMdAddr().c_str());
	pUserApi->Init();
	//�ȴ������¼�ɹ�
	WaitForSingleObject(g_hEvent1, INFINITE);
	//���ľ����Լ��������Ϣ
	redisReply *reply;
	string que = g_confMgr.GetInstrumentQueue();
	rm.BRPop(&reply, que);
	while (reply != NULL && reply->elements == 2) {
		pUserApi->SubscribeMarketData(&(reply->element[1]->str), 1);
		cout<<reply->element[1]->str<<endl;
		freeReplyObject(reply);
		rm.BRPop(&reply, que);
	}
	//����
	cout<<"join"<<endl;
	pUserApi->Join();
	pUserApi->Release();
	pTraderApi->Join();
	pTraderApi->Release();

	return 0;
}