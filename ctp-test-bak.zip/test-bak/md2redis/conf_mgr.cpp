#include "conf_mgr.h"
#include "tinyxml2.h"
using namespace tinyxml2;

ConfMgr::ConfMgr(string filename)
{
	this->filename = filename;
	mdAddr = "tcp://180.168.146.187:10010";
	tradeAddr = "tcp://180.168.146.187:10001";
	redisAddr = "localhost";
	redisPort = 6379;
	redisMdChnl = "CustomMdChannel";
	instrumentQueue = "insQue";
}

void ConfMgr::Init()
{
	XMLDocument doc;
	if (doc.LoadFile(filename.c_str()))
		return;
	XMLElement *root = doc.RootElement();
	XMLElement *elemMdAddr = root->FirstChildElement("mdAddr");
	if (elemMdAddr != NULL) {
		mdAddr = elemMdAddr->GetText();
	}
	XMLElement *elemTradeAddr = root->FirstChildElement("tradeAddr");
	if (elemTradeAddr != NULL) {
		tradeAddr = elemTradeAddr->GetText();
	}
	XMLElement *elemRedisAddr = root->FirstChildElement("redisAddr");
	if (elemRedisAddr != NULL) {
		redisAddr = elemRedisAddr->GetText();
	}
	XMLElement *elemRedisPort = root->FirstChildElement("redisPort");
	if (elemRedisPort != NULL) {
		redisPort = atoi(elemRedisPort->GetText());
	}
	XMLElement *elemRedisMdChnl = root->FirstChildElement("redisMdChnl");
	if (elemRedisMdChnl != NULL) {
		redisMdChnl = elemRedisMdChnl->GetText();
	}
	XMLElement *elemInstrumentQueue = root->FirstChildElement("instrumentQueue");
	if (elemInstrumentQueue != NULL) {
		instrumentQueue = elemInstrumentQueue->GetText();
	}
	XMLElement *elemInstrumentID = root->FirstChildElement("instrumentID");
	if (elemInstrumentID != NULL) {
		XMLElement *item = elemInstrumentID->FirstChildElement("item");
		while (item != NULL) {
			instrumentIdList.push_back(item->GetText());
			item = item->NextSiblingElement();
		}
	}
	XMLElement *elem;
	elem = root->FirstChildElement("brokerID");
	if (elem != NULL) {
		brokerID = elem->GetText();
	}
	elem = root->FirstChildElement("userID");
	if (elem != NULL) {
		userID = elem->GetText();
	}
	elem = root->FirstChildElement("password");
	if (elem != NULL) {
		password = elem->GetText();
	}
}

string ConfMgr::GetMdAddr()
{
	return mdAddr;
}
string ConfMgr::GetTradeAddr()
{
	return tradeAddr;
}
string ConfMgr::GetBrokerID()
{
	return brokerID;
}
string ConfMgr::GetUserID()
{
	return userID;
}
string ConfMgr::GetPassword()
{
	return password;
}
string ConfMgr::GetRedisAddr()
{
	return redisAddr;
}
int ConfMgr::GetRedisPort()
{
	return redisPort;
}
string ConfMgr::GetRedisMdChnl()
{
	return redisMdChnl;
}
string ConfMgr::GetInstrumentQueue()
{
	return instrumentQueue;
}
vector<string> ConfMgr::GetInstrumentIdList()
{
	return instrumentIdList;
}
