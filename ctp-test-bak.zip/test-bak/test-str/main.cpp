#include <iostream>
#include <sstream>

using namespace std;

void test_stringstream()
{
	stringstream ss;
	string s;
	string name = "aaa";
	int age = 30;
	ss<<"{\"name\":\""<<name
		<<"\",\"age\":"<<age<<"}";
	ss>>s;
	cout<<s<<endl;
	ss.clear();
	ss.str("");
	ss<<"hello,world.";
	cout<<ss.str()<<endl;
}

void test_strs()
{
	string strs[] = {"aaa", "bbb", "ccc"};
	cout<<sizeof(strs)<<endl;
	char **strs1 = (char**)malloc(3*sizeof(char*));
	strs1[0] = (char*)strs[0].c_str();
	strs1[1] = (char*)strs[1].c_str();
	strs1[2] = (char*)strs[2].c_str();
	cout<<strs1[0]<<endl;
	cout<<strs1[1]<<endl;
	cout<<strs1[2]<<endl;
}

int main()
{
	test_strs();
	return 0;
}