#include <iostream>
#include "hiredis.h"

#pragma comment(lib, "hiredis.lib")
#pragma comment(lib, "ws2_32.lib")

using namespace std;

void ProcessReply(redisReply *pReply)
{
	redisReply * pSubReply = NULL;
	if (pReply != NULL && pReply->elements == 3) {
		pSubReply = pReply->element[2];
		printf("Msg [%s]\n", pSubReply->str);
	}
}

int main()
{
	WSADATA wsaData;
    int nRet;
    if((nRet = WSAStartup(MAKEWORD(2,2),&wsaData)) != 0){
        printf("WSAStartup failed\n");
        exit(0);
    }
	redisContext* c = redisConnect("127.0.0.1", 6379);
	if ( c->err)
    {
        printf("Connect to redisServer faile:%s\n",c->errstr);
        redisFree(c);
        return 1;
    }
    printf("Connect to redisServer Success\n");
	redisReply *reply;
	//set key
	//reply = (redisReply *)redisCommand(c, "SET %s %s", "foo", "С�������");
	reply = (redisReply *)redisCommand(c, "PUBLISH %s %s", "redisChat", "xiaoming is a badboy");
	printf("SET: %s\n", reply->str);
	freeReplyObject(reply);
	//get key
	reply = (redisReply *)redisCommand(c, "GET foo");
	printf("GET foo: %s\n", reply->str);
	freeReplyObject(reply);
	//subscribe
	redisReply * pReply = (redisReply *)redisCommand(c, "SUBSCRIBE %s", "redisChat");
	freeReplyObject(pReply);
	while (redisGetReply( c, (void **)&pReply ) == REDIS_OK) {
		ProcessReply(pReply);
		freeReplyObject(pReply);
	}
/*
	//nonblock queue
	reply = (redisReply *)redisCommand(c, "RPOP myque");
	while (reply != NULL && reply->str != NULL) {
		printf("RPOP myque: %s\n", reply->str);
		freeReplyObject(reply);
		reply = (redisReply *)redisCommand(c, "RPOP myque");
	}

	//block queue
	reply = (redisReply *)redisCommand(c, "BRPOP myque 0");
	while (reply != NULL && reply->elements == 2) {
		printf("RPOP myque: %s\n", reply->element[1]->str);
		freeReplyObject(reply);
		reply = (redisReply *)redisCommand(c, "BRPOP myque 0");
	}
*/
	printf("redis free.\n");
	redisFree(c);
	return 0;
}