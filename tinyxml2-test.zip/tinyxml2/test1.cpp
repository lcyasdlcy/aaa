#include <stdio.h>
#include <iostream>
#include "tinyxml2.h"

using namespace tinyxml2;
using namespace std;

int main()
{
	cout<<"tinyxml2 test1."<<endl;
	cout<<"--------------------------"<<endl;
	cout<<"read from file."<<endl;
	cout<<"--------------------------"<<endl;
	XMLDocument doc;
	if (doc.LoadFile("./user.xml") != 0) {
		cout<<"load xml file failed."<<endl;
		return 1;
	}
	doc.Print();
	cout<<"--------------------------"<<endl;
	cout<<"read from memory."<<endl;
	cout<<"--------------------------"<<endl;
	FILE *fp = fopen("user.xml", "r");
	if (fp == NULL) {
		cout<<"open file failed."<<endl;
		return 1;
	}
	fseek(fp, 0, SEEK_END);
	int len = ftell(fp);
	cout<<"file length is "<<len<<endl;
	char *buf = (char*)malloc(len+1);
	memset(buf, 0, len+1);
	fseek(fp, 0, SEEK_SET);
	fread(buf, len, 1, fp);
	//printf("%s\n", buf);
	XMLDocument doc1;
	doc1.Parse(buf);
	free(buf);
	doc1.Print();
	cout<<"--------------------------"<<endl;
	cout<<"get xml declaration"<<endl;
	cout<<"--------------------------"<<endl;
	XMLNode *decl = doc1.FirstChild();
	XMLDeclaration *declaration = decl->ToDeclaration();
	cout<<declaration->Value()<<endl;
	cout<<"--------------------------"<<endl;
	cout<<"add xml element"<<endl;
	cout<<"--------------------------"<<endl;
	XMLElement *root = doc1.RootElement();
	XMLElement *userNode = doc1.NewElement("user");
	userNode->SetAttribute("name", "ccc");
	userNode->SetAttribute("age", "11");
	root->InsertEndChild(userNode);
	userNode = doc1.NewElement("user");
	userNode->SetAttribute("name", "xiaoming");
	userNode->SetAttribute("age", "22");
	XMLElement *descNode = doc1.NewElement("description");
	XMLText *descText = doc1.NewText("xiaoming is a good boy");
	descNode->InsertEndChild(descText);
	userNode->InsertEndChild(descNode);
	root->InsertEndChild(userNode);
	doc1.Print();
	cout<<"--------------------------"<<endl;
	cout<<"find xml element"<<endl;
	cout<<"--------------------------"<<endl;
	XMLElement *userNode1 = root->FirstChildElement("user");
	while (userNode1 != NULL) {
		const char *name = userNode1->Attribute("name");
		cout<<name<<endl;
		if (strcmp(name, "xiaoming") == 0) {
			XMLElement *descNode1 = userNode1->FirstChildElement("description");
			cout<<descNode1->GetText()<<endl;
		}
		userNode1 = userNode1->NextSiblingElement();
	}
	cout<<"--------------------------"<<endl;
	cout<<"save xml element to file"<<endl;
	cout<<"--------------------------"<<endl;
	doc1.SaveFile("user1.xml");
	cout<<"save ok"<<endl;

	return 0;
}
