#include <iostream>
#include "tinyxml2.h"
#include <vector>

using namespace tinyxml2;
using namespace std;

string getAppsXml()
{
	string xml;
	FILE *fp = fopen("apps.xml", "r");
	if (fp == NULL) {
		return "";
	}
	fseek(fp, 0, SEEK_END);
	long len = ftell(fp);
	char *buf = (char*)malloc(len+1);
	memset(buf, 0, len+1);
	fseek(fp, 0, SEEK_SET);
	fread(buf, len, 1, fp);
	fclose(fp);
	xml = buf;
	free(buf);
	return xml;
}

vector<string> getUrlListByName(const string &xml, const string &name)
{
	vector<string> urlList;
	XMLDocument doc;
	doc.Parse(xml.c_str());
	XMLElement *root = doc.RootElement();
	XMLElement *application = root->FirstChildElement("application");
	XMLElement *appname = NULL;
	while (application != NULL) {
		appname = application->FirstChildElement("name");
		if (strcmp(appname->GetText(), name.c_str()) == 0)
			break;
		application = application->NextSiblingElement();
	}
	if (application != NULL) {
		XMLElement *appInstance = application->FirstChildElement("instance");
		XMLElement *homePageUrl = NULL;
		while (appInstance != NULL) {
			homePageUrl = appInstance->FirstChildElement("homePageUrl");
			if (homePageUrl != NULL) {
				urlList.push_back(homePageUrl->GetText());
			}
			appInstance = appInstance->NextSiblingElement();
		}
	}
	return urlList;
}

string randomOne(vector<string> &all)
{
	int len = all.size();
	int i = rand()%len;
	return all[i];
}

int main()
{
	string xml = getAppsXml();
//	cout<<xml<<endl;
	vector<string> urlList = getUrlListByName(xml, "SERVICE-HI");
//	vector<string>::iterator it = urlList.begin();
//	for (; it!=urlList.end(); it++) {
//		cout<<*it<<endl;
//	}
	for (int i=0; i<10; i++) {
		cout<<i<<": "<<randomOne(urlList)<<endl;
	}
	return 0;
}
